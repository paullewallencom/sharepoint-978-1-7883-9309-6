-- To be run agains master DB
CREATE LOGIN WebHooksAdmin WITH PASSWORD = 'learning1!'